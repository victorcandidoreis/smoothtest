
# check.library -----------------------------------------------------------

check.library=function(packages.names,...)
{
  
  check=packages.names %in% (.packages())
  invisible(sapply(1:length(check), function(a)
  {
    
    if(!check[a])
    {
      library(packages.names[a],character.only = T)
    }
    
  }))
  
}

# h0.generate --------------------------------------------------------

h0.generate=function(number,...)
{
  return(rnorm(number))
}


# parallel.run ------------------------------------------------------------

parallel.run=function(remove.number,...)
{
  
  check.library(c("doParallel","foreach"))
  
  nc=min(detectCores()-remove.number,1)
  
  cluster.object=makeCluster(nc)
  
  registerDoParallel(cluster.object)
  
  assign("cluster.object",cluster.object,envir = parent.frame())
  
}

# similarity.function ---------------------------------------------------------

similarity.function=function(elements,band.width,squared.distances=NULL,...)
{
  
  if(is.list(elements))
  {
    elements2=as.matrix(elements[[2]])
    elements=as.matrix(elements[[1]])
  } else {
    elements=as.matrix(elements)
    elements2=NULL
  }
  
  #
  
  if(is.null(squared.distances))
  {
    squared.distances=(fields::rdist(elements,elements2))^2
  }
  
  return(exp(-(1/band.width)*squared.distances))
  
}

# spectral.base ---------------------------------------------------------

spectral.base=function(base.elements,i.break,similarity.function,...,
                       base.similarity=NULL)
{
  
  
  base.elements=as.matrix(base.elements)
  
  if(is.null(base.similarity))
  {
    base.similarity=similarity.function(base.elements,...)
  }
  
  base.marginal.sums=colSums(base.similarity)
  
  s.measure=base.marginal.sums/sum(base.marginal.sums)
  
  i.sqrt.s.measure=1/sqrt(s.measure)
  
  symmetric.matrix=crossprod(t(crossprod(diag(
    i.sqrt.s.measure),base.similarity)),diag(
      i.sqrt.s.measure))
  
  eigen.decomposition=eigen(symmetric.matrix,T)
  
  eigen.values=eigen.decomposition$values[1:(i.break+1)]
  
  base.eigen.functions=crossprod(diag(i.sqrt.s.measure),
                                 eigen.decomposition$vectors)[,1:(i.break+1)]
  
  spectral..base=list(
    base.eigen.functions=base.eigen.functions,
    
    eigen.values=eigen.values,
    
    base.elements=base.elements,
    
    base.marginal.sums=base.marginal.sums,
    
    similarity.function=similarity.function,
    
    args.similarity.number=length(list(...)),
    
    ...
  )
  
  return(spectral..base)
  
}

# extension.eigen.functions -----------------------------------------------------

extension.eigen.functions=function(extesion.elements,
                                   spectral..base,...)
{
  base.eigen.functions=spectral..base$base.eigen.functions
  
  eigen.values=spectral..base$eigen.values
  
  base.elements=spectral..base$base.elements
  
  base.marginal.sums=spectral..base$base.marginal.sums
  
  similarity.function=spectral..base$similarity.function
  
  args.similarity=tail(spectral..base,spectral..base$
                         args.similarity.number)
  
  #
  
  extesion.elements=as.matrix(extesion.elements)
  
  number.base.elements=nrow(base.elements)
  
  similarity.base.extension=do.call(similarity.function,
                                    c(list(list(base.elements,extesion.elements)),
                                      args.similarity))
  
  base.extension.marginal.sums=colSums(
    similarity.base.extension) #base maginal
  
  base.extension.marginal.sums[
    base.extension.marginal.sums<1e-8]=1e-8
  
  extension.eigen..functions=crossprod(
    t(crossprod(
      diag(1/base.extension.marginal.sums),
      crossprod( 
        similarity.base.extension,
        base.eigen.functions)
    )),
    diag(1/eigen.values)
  )
  
  extension..eigen..functions=list(
    extension.eigen.functions=
      extension.eigen..functions,
    
    base.extension.marginal.sums=
      base.extension.marginal.sums,
    
    base.marginal.sums=base.marginal.sums,
    
    number.base.elements=number.base.elements
  )
  
  return(extension..eigen..functions)
  
}


# test.combined.expansion.coefficients ---------------------------------------------------------------

test.combined.expansion.coefficients=function(
  test.extension.eigen.functions,
  partial=T,...)
{
  #extension.eigen.functions with:
  #base.elements=h0 sample; 
  #extension.elements=taget sample
  
  extension.eigen..functions=
    test.extension.eigen.functions$
    extension.eigen.functions
  
  base.extension.marginal.sums=
    test.extension.eigen.functions$
    base.extension.marginal.sums
  
  base.marginal.sums=
    test.extension.eigen.functions$
    base.marginal.sums
  
  number.base.elements=
    test.extension.eigen.functions$
    number.base.elements
  
  #
  
  new.s.measure=base.extension.marginal.sums/
    sum(base.marginal.sums)
  
  combined.expansion.coefficients=number.base.elements*colMeans(
    crossprod(diag(new.s.measure),
              extension.eigen..functions) 
  )
  
  if(partial)
  {
    
    return(cumsum(combined.expansion.coefficients[-1]^2))
    
  } else {
    
    return(sum(combined.expansion.coefficients[-1]^2))
    
  }
  
}

# test.calculate.h0.spectral.bases.arg -------------------------------------

test.calculate.h0.spectral.bases.arg=function(h0.spectral.bases.sample,i.break,
                                              similarity.function,band.widths,...)
  
{
  
  if(!is.null(band.widths))
  {
    
    parallel.run(2)
    result=foreach(a=band.widths) %dopar%
      {
        source("copy_functions.R")
        
        spectral.base(h0.spectral.bases.sample,
                      i.break,similarity.function,band.width=a)
      }
    stopCluster(cluster.object)
    
    result
  }
}

# test.calculate.h0.standardizations.lambda --------------------------------

test.calculate.h0.standardizations.lambda=function(
  h0.distributions.lambda.sample,h0.distributions.lambda,...)
{
  pares=lapply(h0.distributions.lambda, function(a)
  {
    c(mean(a),sd(a))
  })
  mean=sapply(pares, function(a) a[1])
  sd=sapply(pares, function(a) a[2])
  
  list(mean=mean,sd=sd)
  
}

# test.calculate.statistic -------------------------------------------------

test.calculate.statistic=function(sample,h0.spectral.bases.arg,h0.distributions.lambda=NULL,
                                  h0.standardizations.lambda=NULL,complete=T,...)
{
  
  
  extensions=lapply(h0.spectral.bases.arg, function(a) 
  {
    extension.eigen.functions(sample,a,...)  
  })
  
  combined.expansions=as.vector(sapply(extensions, function(a) 
  {
    test.combined.expansion.coefficients(a,...)  
  }))
  
  if(complete)
  {
    p=sapply(1:length(h0.distributions.lambda), function(a)
      mean(h0.distributions.lambda[[a]]>combined.expansions[a]))
    
    mean=h0.standardizations.lambda$mean
    
    sd=h0.standardizations.lambda$sd
    
    t=(combined.expansions-mean)/sd
    
    sum((1-p)*abs(t))
    
  } else {
    combined.expansions
  }
  
}

# test.calculate.h0.distributions.lambda -----------------------------------------

test.calculate.h0.distributions.lambda=function(
  h0.distributions.lambda.sample,h0.spectral.bases.arg,...)
{
  
  parallel.run(2)
  partial=foreach(a=h0.distributions.lambda.sample,.combine = cbind) %dopar%
    {
      source("copy_functions.R")
      
      test.calculate.statistic(a,h0.spectral.bases.arg,complete=F,...)
    }
  stopCluster(cluster.object)
  
  lapply(1:nrow(partial), function(a)
  {
    partial[a,]
  })
}


# test.calculate.h0.statistic.distribution --------------------------------

test.calculate.h0.statistic.distribution=function(
  h0.statistic.distribution.sample,h0.spectral.bases.arg,
  h0.distributions.lambda,h0.standardizations.lambda,...)
{
  
  parallel.run(2)
  result=foreach(a=h0.statistic.distribution.sample) %dopar%
    {
      
      source("copy_functions.R")
      
      test.calculate.statistic(a,h0.spectral.bases.arg,
                               h0.distributions.lambda,h0.standardizations.lambda,T,...)
    }
  stopCluster(cluster.object)
  
  result
  
}

